# pythonmomo
A simple to use python wrapper to integrate the MTN Uganda API into your projects.

# Getting started

### Authors
- [Abulo John Joshua](https://github.com/abulojoshua1)
- [Allan Guwatudde](https://github.com/AGMETEOR)